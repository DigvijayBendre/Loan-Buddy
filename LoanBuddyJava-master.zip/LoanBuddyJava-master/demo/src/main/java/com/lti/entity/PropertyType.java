package com.lti.entity;

public enum PropertyType {
	AGRICULTURAL, RESIDENTIAL, COMMERCIAL, INDUSTRIAL

}
