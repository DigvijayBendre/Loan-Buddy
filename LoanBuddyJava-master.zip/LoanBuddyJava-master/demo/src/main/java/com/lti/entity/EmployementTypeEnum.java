package com.lti.entity;

public enum EmployementTypeEnum {
	SALARIED, SELF_EMPLOYED;
}
