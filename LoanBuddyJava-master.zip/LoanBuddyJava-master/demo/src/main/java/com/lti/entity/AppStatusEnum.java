package com.lti.entity;

public enum AppStatusEnum {
	APPROVED, SENT_FOR_VERIFICARION, REJECTED;
}
