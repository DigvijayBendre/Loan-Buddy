package com.lti.entity;

public enum PropertyType {
	RESIDENTIAL, COMMERCIAL, INDUSTRIAL

}
